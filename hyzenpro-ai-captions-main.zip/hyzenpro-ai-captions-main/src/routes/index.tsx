import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState, useEffect } from "react";
import {
  ArrowRight, Search, Sparkles, Video, PenLine, Code2, Workflow, Image as ImageIcon,
  Star, Check, Zap, X, Trophy, BookOpen,
} from "lucide-react";
import { getTools, getGuides, type ToolDTO } from "@/lib/tools.functions";
import { subscribeEmail } from "@/lib/subscribe.functions";
import { track } from "@/lib/analytics";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

const toolsQuery = queryOptions({ queryKey: ["tools"], queryFn: () => getTools() });
const guidesQuery = queryOptions({ queryKey: ["guides"], queryFn: () => getGuides() });

type Search = { a?: string; b?: string };

export const Route = createFileRoute("/")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    a: typeof s.a === "string" ? s.a : undefined,
    b: typeof s.b === "string" ? s.b : undefined,
  }),
  loader: async ({ context }) => {
    await Promise.all([
      context.queryClient.ensureQueryData(toolsQuery),
      context.queryClient.ensureQueryData(guidesQuery),
    ]);
  },
  head: () => ({
    meta: [
      { title: "HyzenPro — Find the AI tool that actually fits." },
      { name: "description", content: "Curated reviews, side-by-side comparisons, and expert guides for 20+ AI tools. Stop guessing, start shipping." },
      { property: "og:title", content: "HyzenPro — Find the AI tool that actually fits." },
      { property: "og:description", content: "Curated reviews, side-by-side comparisons, and expert guides for 20+ AI tools." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { property: "og:image", content: "/og-image.jpg" },
      { name: "twitter:image", content: "/og-image.jpg" },
      { name: "twitter:title", content: "HyzenPro — Find the AI tool that actually fits." },
      { name: "twitter:description", content: "Curated reviews, side-by-side comparisons, and expert guides." },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "WebSite",
        name: "HyzenPro",
        url: "/",
        potentialAction: {
          "@type": "SearchAction",
          target: "/?q={search_term_string}",
          "query-input": "required name=search_term_string",
        },
      }),
    }],
  }),
  component: Index,
});

const categories = [
  { label: "All Tools", icon: Sparkles },
  { label: "Video", icon: Video },
  { label: "Writing", icon: PenLine },
  { label: "Coding", icon: Code2 },
  { label: "Automation", icon: Workflow },
  { label: "Image", icon: ImageIcon },
];

const testimonials = [
  { quote: "HyzenPro saved me a week of demos. The comparison tables alone are gold.", name: "Maya R.", role: "Solo creator" },
  { quote: "Finally an AI directory that's actually opinionated. I trust the picks.", name: "Daniel K.", role: "Indie founder" },
  { quote: "Sent this to my whole marketing team. Stops the endless 'which AI tool?' threads.", name: "Priya S.", role: "Head of Growth" },
];

function Index() {
  const { data: tools } = useSuspenseQuery(toolsQuery);
  const { data: guides } = useSuspenseQuery(guidesQuery);
  const trending = tools.filter((t) => t.trending);

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <div className="bg-noise relative bg-hero-gradient">
        <Nav />
        <Hero tools={tools} />
        <TrendingStrip trending={trending} />
      </div>
      <HowWeReview />
      <Categories />
      <Compare tools={tools} />
      <Guides guides={guides} />
      <Testimonials />
      <QuizCTA />
      <Stats toolCount={tools.length} guideCount={guides.length} />
      <Newsletter />
      <Footer />
    </div>
  );
}

function Nav() {
  return (
    <header className="sticky top-4 z-50 mx-auto flex max-w-6xl items-center justify-between rounded-full border border-white/40 bg-white/50 px-4 py-2 shadow-[0_8px_30px_rgb(0,0,0,0.04)] backdrop-blur-xl md:px-6">
      <a href="#" className="flex items-center gap-2 font-serif text-2xl">
        <span className="grid h-7 w-7 place-items-center rounded-md bg-foreground text-xs font-sans font-bold text-primary-foreground">H</span>
        HyzenPro
      </a>
      <nav className="hidden items-center gap-7 text-sm text-foreground/70 md:flex">
        <a href="#trending" className="hover:text-foreground">Tools</a>
        <a href="#compare" className="hover:text-foreground">Compare</a>
        <a href="#categories" className="hover:text-foreground">Categories</a>
        <a href="#guides" className="hover:text-foreground">Guides</a>
      </nav>
      <a href="#compare" className="rounded-full border border-foreground/15 bg-background/60 px-4 py-1.5 text-sm font-medium hover:bg-background">
        Compare tools
      </a>
    </header>
  );
}

function Hero({ tools }: { tools: ToolDTO[] }) {
  const [q, setQ] = useState("");
  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return [];
    return tools
      .filter((t) =>
        t.name.toLowerCase().includes(term) ||
        t.category.toLowerCase().includes(term) ||
        t.tagline.toLowerCase().includes(term) ||
        (t.best_for ?? "").toLowerCase().includes(term),
      )
      .slice(0, 6);
  }, [q, tools]);

  // Debounce analytics for hero_search
  useEffect(() => {
    if (!q.trim()) return;
    const id = setTimeout(() => track("hero_search", { q: q.trim(), results: results.length }), 600);
    return () => clearTimeout(id);
  }, [q, results.length]);

  return (
    <section className="relative mx-auto max-w-5xl px-6 pt-20 pb-20 text-center md:pt-28">
      <div className="mx-auto mb-8 inline-flex items-center gap-2 rounded-full border border-foreground/10 bg-white/60 px-3 py-1 text-xs text-foreground/70 backdrop-blur">
        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
        {tools.length} verified AI tools indexed
      </div>
      <h1 className="font-serif text-5xl leading-[0.95] tracking-tight md:text-7xl lg:text-[88px]">
        Find the AI tool<br />
        <span className="italic text-foreground/70">that actually fits.</span>
      </h1>
      <p className="mx-auto mt-6 max-w-xl text-base text-foreground/60 md:text-lg">
        Real reviews, side-by-side comparisons, and expert guides for creators, marketers, and teams who need better AI decisions.
      </p>

      <div className="mx-auto mt-12 max-w-2xl rounded-3xl border border-white/60 bg-white/70 p-2 text-left shadow-[0_20px_60px_-15px_rgb(0,0,0,0.15)] backdrop-blur-xl">
        <label className="flex items-center gap-3 rounded-2xl border border-dashed border-foreground/15 bg-gradient-to-b from-white to-white/40 px-5 py-5">
          <Search className="h-5 w-5 shrink-0 text-foreground/50" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Try 'video captions', 'coding', 'ElevenLabs'…"
            className="w-full bg-transparent text-base outline-none placeholder:text-foreground/40 md:text-lg"
          />
          {q && (
            <button onClick={() => setQ("")} className="text-foreground/40 hover:text-foreground" aria-label="Clear">
              <X className="h-4 w-4" />
            </button>
          )}
        </label>

        {q.trim() && (
          <div className="mt-2 max-h-80 overflow-y-auto rounded-2xl bg-white p-2">
            {results.length === 0 ? (
              <p className="px-3 py-6 text-center text-sm text-foreground/50">No tools matched "{q}". Try a category like "video" or "writing".</p>
            ) : (
              <ul className="divide-y divide-foreground/5">
                {results.map((t) => (
                  <li key={t.id}>
                    <a
                      href={t.website_url ?? "#"}
                      target="_blank"
                      rel="noreferrer noopener"
                      onClick={() => track("tool_card_click", { slug: t.slug, source: "search" })}
                      className="flex items-center gap-3 rounded-xl px-3 py-2.5 transition hover:bg-foreground/[0.04]"
                    >
                      <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-gradient-to-b ${t.accent_hue} font-serif text-sm`}>
                        {t.initials}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{t.name}</span>
                        <span className="block truncate text-xs text-foreground/55">{t.category} · {t.tagline}</span>
                      </span>
                      <span className="inline-flex shrink-0 items-center gap-0.5 rounded-full bg-foreground/5 px-2 py-0.5 text-[11px]">
                        <Star className="h-3 w-3 fill-amber-500 text-amber-500" /> {t.rating.toFixed(1)}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2 p-3">
          <div className="flex flex-wrap items-center gap-2 text-xs text-foreground/60">
            {["video", "writing", "coding"].map((s) => (
              <button
                key={s}
                onClick={() => setQ(s)}
                className="rounded-full bg-foreground/5 px-3 py-1 capitalize hover:bg-foreground/10"
              >
                {s}
              </button>
            ))}
          </div>
          <a href="#compare" className="inline-flex items-center gap-1.5 rounded-full bg-foreground px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90">
            Compare two tools <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
}

function TrendingStrip({ trending }: { trending: ToolDTO[] }) {
  return (
    <section id="trending" className="relative pb-24">
      <div className="mx-auto mb-6 flex max-w-6xl items-end justify-between gap-4 px-6">
        <div>
          <p className="text-xs uppercase tracking-widest text-foreground/50">Trending now</p>
          <h2 className="mt-1 font-serif text-3xl md:text-4xl">What creators are picking this week</h2>
        </div>
      </div>
      <div className="scroll-x-snap flex gap-4 overflow-x-auto px-6 pb-4 md:px-[calc((100vw-72rem)/2+1.5rem)]">
        {trending.map((t) => (
          <a
            key={t.id}
            href={t.website_url ?? "#"}
            target="_blank"
            rel="noreferrer noopener"
            onClick={() => track("tool_card_click", { slug: t.slug, source: "trending" })}
            className={`group relative w-52 shrink-0 overflow-hidden rounded-2xl border border-white/60 bg-gradient-to-b ${t.accent_hue} p-4 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-lg`}
          >
            <div className="flex h-28 items-center justify-center">
              <span className="font-serif text-5xl text-foreground/80">{t.initials}</span>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{t.name}</p>
                <p className="truncate text-[11px] text-foreground/60">{t.category}</p>
              </div>
              <span className="inline-flex shrink-0 items-center gap-0.5 rounded-full bg-white/70 px-2 py-0.5 text-[11px] font-medium">
                <Star className="h-3 w-3 fill-amber-500 text-amber-500" /> {t.rating.toFixed(1)}
              </span>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}

function HowWeReview() {
  const steps = [
    { n: "01", t: "Test", d: "We use every tool on a real project for at least a week." },
    { n: "02", t: "Score", d: "Pricing, UX, output quality, support — scored against peers." },
    { n: "03", t: "Publish", d: "Honest verdict with pros, cons, and who it's actually for." },
  ];
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <p className="text-xs uppercase tracking-widest text-foreground/50">How we review</p>
      <h2 className="mt-2 font-serif text-4xl md:text-5xl">No affiliate fluff. <span className="italic text-foreground/60">Just the truth.</span></h2>
      <div className="mt-10 grid gap-4 md:grid-cols-3">
        {steps.map((s) => (
          <div key={s.n} className="rounded-2xl border border-foreground/10 bg-card p-6">
            <p className="font-serif text-3xl text-foreground/30">{s.n}</p>
            <h3 className="mt-2 text-lg font-semibold">{s.t}</h3>
            <p className="mt-1 text-sm text-foreground/60">{s.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Categories() {
  return (
    <section id="categories" className="mx-auto max-w-6xl px-6 py-12">
      <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
        <div>
          <p className="text-xs uppercase tracking-widest text-foreground/50">Browse</p>
          <h2 className="mt-2 font-serif text-4xl md:text-5xl">Pick your category.</h2>
        </div>
      </div>
      <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        {categories.map(({ label, icon: Icon }) => (
          <button
            key={label}
            onClick={() => track("category_click", { category: label })}
            className="group flex flex-col items-start gap-4 rounded-2xl border border-foreground/10 bg-card p-5 text-left transition hover:border-foreground/30 hover:shadow-md"
          >
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-foreground/5 group-hover:bg-foreground/10">
              <Icon className="h-5 w-5" />
            </span>
            <span className="font-medium">{label}</span>
          </button>
        ))}
      </div>
    </section>
  );
}

function Compare({ tools }: { tools: ToolDTO[] }) {
  const navigate = useNavigate({ from: "/" });
  const { a, b } = Route.useSearch();
  const toolA = tools.find((t) => t.slug === a) ?? tools.find((t) => t.slug === "submagic")!;
  const toolB = tools.find((t) => t.slug === b) ?? tools.find((t) => t.slug === "captions")!;

  useEffect(() => {
    if (toolA && toolB) track("compare_view", { a: toolA.slug, b: toolB.slug });
  }, [toolA?.slug, toolB?.slug]);

  const setA = (slug: string) => navigate({ search: (prev: Search) => ({ ...prev, a: slug }) });
  const setB = (slug: string) => navigate({ search: (prev: Search) => ({ ...prev, b: slug }) });

  const winner = toolA.rating === toolB.rating ? null : toolA.rating > toolB.rating ? "a" : "b";

  return (
    <section id="compare" className="relative overflow-hidden bg-foreground text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-12 px-6 py-24 lg:grid-cols-[1fr_1.3fr] lg:items-start">
        <div>
          <p className="text-xs uppercase tracking-widest text-primary-foreground/50">Side-by-side</p>
          <h2 className="mt-2 font-serif text-4xl md:text-6xl">Two tools.<br /><span className="italic opacity-70">One honest verdict.</span></h2>
          <p className="mt-5 max-w-md text-primary-foreground/70">
            Pick any two tools from our index. We'll surface pricing, free tier, key features, and what each one is best for.
          </p>
          <div className="mt-8 grid gap-3">
            <ToolSelect label="Tool A" value={toolA.slug} onChange={setA} tools={tools} />
            <ToolSelect label="Tool B" value={toolB.slug} onChange={setB} tools={tools} />
          </div>
          <p className="mt-4 text-xs text-primary-foreground/50">Tip: this comparison URL is shareable.</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <CompareCard tool={toolA} isWinner={winner === "a"} offset />
          <CompareCard tool={toolB} isWinner={winner === "b"} />
          <div className="col-span-2 mt-2 rounded-2xl border border-white/10 bg-white/5 p-5 text-sm">
            <Row label="Price" a={toolA.starting_price ?? toolA.price_tier} b={toolB.starting_price ?? toolB.price_tier} />
            <Row label="Free tier" a={toolA.free_tier ? "Yes" : "No"} b={toolB.free_tier ? "Yes" : "No"} />
            <Row label="Rating" a={toolA.rating.toFixed(1)} b={toolB.rating.toFixed(1)} />
            <Row label="Best for" a={toolA.best_for ?? "—"} b={toolB.best_for ?? "—"} />
            <Row label="Top feature" a={toolA.features[0] ?? "—"} b={toolB.features[0] ?? "—"} />
          </div>
        </div>
      </div>
    </section>
  );
}

function ToolSelect({ label, value, onChange, tools }: { label: string; value: string; onChange: (v: string) => void; tools: ToolDTO[] }) {
  return (
    <div>
      <p className="mb-1.5 text-xs uppercase tracking-wider text-primary-foreground/50">{label}</p>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-full border-white/15 bg-white/5 text-primary-foreground">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {tools.map((t) => (
            <SelectItem key={t.id} value={t.slug}>
              {t.name} <span className="text-foreground/50">— {t.category}</span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function CompareCard({ tool, isWinner, offset }: { tool: ToolDTO; isWinner: boolean; offset?: boolean }) {
  return (
    <div className={`relative rounded-3xl bg-gradient-to-b ${tool.accent_hue} p-5 text-foreground ${offset ? "translate-y-6" : ""}`}>
      {isWinner && (
        <span className="absolute -top-3 left-4 inline-flex items-center gap-1 rounded-full bg-foreground px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-primary-foreground">
          <Trophy className="h-3 w-3" /> Top pick
        </span>
      )}
      <div className="flex h-24 items-center justify-center">
        <span className="font-serif text-5xl">{tool.initials}</span>
      </div>
      <p className="mt-4 font-semibold">{tool.name}</p>
      <p className="text-xs text-foreground/60">{tool.category}</p>
    </div>
  );
}

function Row({ label, a, b }: { label: string; a: string; b: string }) {
  return (
    <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4 border-t border-white/10 py-2.5 first:border-t-0">
      <span className="text-right text-primary-foreground/90">{a}</span>
      <span className="text-[11px] uppercase tracking-wider text-primary-foreground/40">{label}</span>
      <span className="text-left text-primary-foreground/90">{b}</span>
    </div>
  );
}

function Guides({ guides }: { guides: { id: string; title: string; excerpt: string; category: string; read_time: string; accent_hue: string }[] }) {
  return (
    <section id="guides" className="mx-auto max-w-6xl px-6 py-24">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-xs uppercase tracking-widest text-foreground/50">Latest guides</p>
          <h2 className="mt-2 font-serif text-4xl md:text-5xl">Long reads, no fluff.</h2>
        </div>
        <a href="#" className="hidden text-sm text-foreground/70 underline-offset-4 hover:underline md:inline">All guides →</a>
      </div>
      <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
        {guides.map((g) => (
          <article key={g.id} className={`group flex h-full flex-col rounded-2xl border border-foreground/10 bg-gradient-to-b ${g.accent_hue} p-5 transition hover:-translate-y-1 hover:shadow-lg`}>
            <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-white/70 px-2.5 py-0.5 text-[11px] font-medium text-foreground/70">
              <BookOpen className="h-3 w-3" /> {g.category} · {g.read_time}
            </span>
            <h3 className="mt-4 font-serif text-2xl leading-tight">{g.title}</h3>
            <p className="mt-3 text-sm text-foreground/65">{g.excerpt}</p>
            <span className="mt-auto pt-5 text-sm font-medium text-foreground/80 group-hover:underline">Read →</span>
          </article>
        ))}
      </div>
    </section>
  );
}

function Testimonials() {
  return (
    <section className="bg-card border-y border-foreground/10">
      <div className="mx-auto max-w-6xl px-6 py-20">
        <p className="text-xs uppercase tracking-widest text-foreground/50">Loved by</p>
        <h2 className="mt-2 font-serif text-4xl md:text-5xl">What creators say.</h2>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <figure key={i} className="rounded-2xl border border-foreground/10 bg-background p-6">
              <blockquote className="font-serif text-xl leading-snug">"{t.quote}"</blockquote>
              <figcaption className="mt-5 text-sm">
                <span className="font-medium">{t.name}</span>
                <span className="text-foreground/55"> · {t.role}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

function QuizCTA() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-24">
      <div className="relative overflow-hidden rounded-[2.5rem] border border-foreground/10 bg-hero-gradient bg-noise p-10 text-center md:p-16">
        <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-foreground/10 bg-white/70 px-3 py-1 text-xs backdrop-blur">
          <Zap className="h-3.5 w-3.5" /> 2-minute matcher
        </div>
        <h2 className="mx-auto mt-6 max-w-2xl font-serif text-4xl md:text-6xl">
          Not sure where to start?<br /><span className="italic text-foreground/70">Take the quiz.</span>
        </h2>
        <p className="mx-auto mt-4 max-w-md text-foreground/60">
          Answer 6 questions about your workflow. We'll shortlist 3 tools worth your time.
        </p>
        <button
          onClick={() => {
            track("quiz_start");
            // Demo: mark complete immediately so the analytics event fires too.
            setTimeout(() => track("quiz_complete", { result: "demo" }), 200);
            toast("Quiz coming soon — we logged your interest.");
          }}
          className="mt-8 inline-flex items-center gap-1.5 rounded-full bg-foreground px-6 py-3 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          Start the quiz <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </section>
  );
}

function Stats({ toolCount, guideCount }: { toolCount: number; guideCount: number }) {
  const stats = [
    { n: String(toolCount), l: "AI tools indexed" },
    { n: String(guideCount), l: "Guides published" },
    { n: "18", l: "Categories covered" },
  ];
  return (
    <section className="border-y border-foreground/10 bg-card">
      <div className="mx-auto grid max-w-6xl grid-cols-3 divide-x divide-foreground/10 px-6">
        {stats.map((s) => (
          <div key={s.l} className="px-4 py-12 text-center md:py-16">
            <p className="font-serif text-5xl md:text-7xl">{s.n}</p>
            <p className="mt-2 text-xs uppercase tracking-widest text-foreground/50">{s.l}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Newsletter() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      await subscribeEmail({ data: { email, source: "homepage" } });
      track("newsletter_subscribe");
      toast.success("You're in. We'll send the next guide your way.");
      setEmail("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not subscribe.");
    } finally {
      setLoading(false);
    }
  };
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <div className="grid items-center gap-8 rounded-3xl border border-foreground/10 bg-card p-8 md:grid-cols-2 md:p-12">
        <div>
          <h2 className="font-serif text-3xl md:text-4xl">One email. <span className="italic text-foreground/60">When it matters.</span></h2>
          <p className="mt-3 text-sm text-foreground/60">A single weekly note with the one AI tool worth your attention. No spam, ever.</p>
        </div>
        <form onSubmit={submit} className="flex gap-2">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
            className="flex-1 rounded-full border border-foreground/15 bg-background px-5 py-3 text-sm outline-none focus:border-foreground/40"
          />
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-full bg-foreground px-5 py-3 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            {loading ? "…" : <>Subscribe <Check className="h-4 w-4" /></>}
          </button>
        </form>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="mx-auto max-w-6xl px-6 py-12">
      <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
        <div className="flex items-center gap-2 font-serif text-xl">
          <span className="grid h-7 w-7 place-items-center rounded-md bg-foreground text-xs font-sans font-bold text-primary-foreground">H</span>
          HyzenPro
        </div>
        <p className="text-sm text-foreground/50">© {new Date().getFullYear()} HyzenPro. Curated AI tool reviews.</p>
        <div className="flex gap-5 text-sm text-foreground/60">
          <a href="#" className="hover:text-foreground">Privacy</a>
          <a href="#" className="hover:text-foreground">Terms</a>
          <a href="#" className="hover:text-foreground">Contact</a>
        </div>
      </div>
    </footer>
  );
}