import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getRequestHeader } from "@tanstack/react-start/server";

const TrackEventInput = z.object({
  event: z.string().min(1).max(64).regex(/^[a-z0-9_]+$/i),
  properties: z.record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.null()])).optional(),
  path: z.string().max(512).optional(),
  session_id: z.string().max(64).optional(),
});

export const trackEvent = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => TrackEventInput.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const userAgent = getRequestHeader("user-agent")?.slice(0, 256) ?? null;
    const { error } = await supabaseAdmin.from("analytics_events").insert({
      event_name: data.event,
      properties: data.properties ?? {},
      path: data.path ?? null,
      session_id: data.session_id ?? null,
      user_agent: userAgent,
    });
    if (error) {
      console.error("[analytics] insert failed", error.message);
      return { ok: false };
    }
    return { ok: true };
  });