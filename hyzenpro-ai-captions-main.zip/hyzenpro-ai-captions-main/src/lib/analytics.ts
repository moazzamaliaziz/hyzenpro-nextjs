import { trackEvent } from "./analytics.functions";

type Props = Record<string, string | number | boolean | null>;

function getSessionId(): string {
  if (typeof window === "undefined") return "ssr";
  try {
    let id = sessionStorage.getItem("hp_sid");
    if (!id) {
      id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
      sessionStorage.setItem("hp_sid", id);
    }
    return id;
  } catch {
    return "anon";
  }
}

export function track(event: string, properties?: Props) {
  if (typeof window === "undefined") return;
  // Fan out to any installed analytics scripts (no-ops if absent).
  const w = window as unknown as {
    plausible?: (e: string, opts?: { props?: Props }) => void;
    gtag?: (...args: unknown[]) => void;
  };
  try {
    w.plausible?.(event, properties ? { props: properties } : undefined);
    w.gtag?.("event", event, properties);
  } catch {
    /* ignore */
  }
  // Always persist to our own analytics_events table.
  trackEvent({
    data: {
      event,
      properties: properties ?? {},
      path: window.location.pathname + window.location.search,
      session_id: getSessionId(),
    },
  }).catch(() => {
    /* swallow — analytics must never break UX */
  });
}