import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SubscribeInput = z.object({
  email: z.string().email().max(254),
  source: z.string().max(64).optional(),
});

export const subscribeEmail = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => SubscribeInput.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("subscribers")
      .insert({ email: data.email.toLowerCase().trim(), source: data.source ?? "homepage" });
    if (error && !/duplicate key/i.test(error.message)) {
      throw new Error("Could not subscribe right now. Please try again.");
    }
    return { ok: true };
  });