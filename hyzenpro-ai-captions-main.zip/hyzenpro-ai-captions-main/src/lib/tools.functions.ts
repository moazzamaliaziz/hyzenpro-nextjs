import { createServerFn } from "@tanstack/react-start";

export type ToolDTO = {
  id: string;
  slug: string;
  name: string;
  category: string;
  tagline: string;
  description: string | null;
  rating: number;
  price_tier: string;
  starting_price: string | null;
  free_tier: boolean;
  best_for: string | null;
  features: string[];
  pros: string[];
  cons: string[];
  initials: string;
  accent_hue: string;
  website_url: string | null;
  trending: boolean;
};

export const getTools = createServerFn({ method: "GET" }).handler(async (): Promise<ToolDTO[]> => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("tools")
    .select(
      "id, slug, name, category, tagline, description, rating, price_tier, starting_price, free_tier, best_for, features, pros, cons, initials, accent_hue, website_url, trending",
    )
    .order("rating", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []).map((t) => ({
    ...t,
    rating: Number(t.rating),
    features: Array.isArray(t.features) ? (t.features as string[]) : [],
    pros: Array.isArray(t.pros) ? (t.pros as string[]) : [],
    cons: Array.isArray(t.cons) ? (t.cons as string[]) : [],
  })) as ToolDTO[];
});

export type GuideDTO = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  read_time: string;
  accent_hue: string;
};

export const getGuides = createServerFn({ method: "GET" }).handler(async (): Promise<GuideDTO[]> => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("guides")
    .select("id, slug, title, excerpt, category, read_time, accent_hue")
    .order("created_at", { ascending: false })
    .limit(4);
  if (error) throw new Error(error.message);
  return (data ?? []) as GuideDTO[];
});