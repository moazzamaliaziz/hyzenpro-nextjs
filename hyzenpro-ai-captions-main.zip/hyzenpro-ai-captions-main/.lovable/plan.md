## What I'll build

### 1. Enable Lovable Cloud + seed data
- Turn on Lovable Cloud (managed Postgres + auth + storage, no external accounts).
- Create `tools` table:
  - `id, slug, name, category, tagline, description, rating, price_tier, free_tier, pros[], cons[], features (jsonb), thumbnail_url, accent_hue, trending (bool), created_at`
- Seed ~20 popular AI tools (GPT-4o, Claude, Midjourney, Cursor, Submagic, Captions, ElevenLabs, Runway, Notion AI, Perplexity, v0, Lovable, Figma AI, Suno, Pika, Descript, Synthesia, HeyGen, Krea, Ideogram).
- RLS: public SELECT only; writes via service role (admin/seed only).

### 2. Live hero search card
- Replace static demo text with a real input.
- Server function `searchTools(query)` — case-insensitive match on name, category, tagline, features.
- Results dropdown under the card: top 6 matches as mini cards (logo initials, name, category, rating). Empty state suggests popular tools. Each result links to a (placeholder) tool page.
- Debounced 200ms, keyboard nav (↑↓/Enter).

### 3. Trending scroller → real data
- Loader uses `ensureQueryData` to fetch `tools` where `trending = true`, ordered by rating.
- Cards show real name, category, rating, gradient hue from DB.

### 4. Interactive side-by-side comparison
- Replace static compare mock with two `<Select>` dropdowns (Tool A / Tool B) populated from DB.
- On selection, fetch both tools and render a comparison table: Price, Free tier, Rating, Best for, Top 3 features, Top pros/cons.
- "Winner" badge on the row where one tool clearly leads (higher rating).
- Persist selections in URL search params (`?a=gpt-4o&b=claude-sonnet`) so comparisons are shareable.

### 5. SEO + Open Graph
- Per-route `head()` with title, description, og:title, og:description, og:type=website, og:url, twitter:card=summary_large_image.
- Generate a branded OG image (1200×630) for the home page and reference via `og:image` + `twitter:image`.
- Add `sitemap.xml` and `robots.txt`.
- JSON-LD: WebSite + Organization on the home route.

### 6. Analytics event tracking
- Lightweight client tracker (`src/lib/analytics.ts`) that wraps `window.plausible` / `gtag` if present and always logs to console + a `track_event` server fn that inserts into an `analytics_events` table.
- Events fired:
  - `hero_search` (with query)
  - `category_click` (with category)
  - `quiz_start` / `quiz_complete`
  - `compare_view` (with tool A + B slugs)
  - `tool_card_click` (with slug)

### 7. Additional sections that fit HyzenPro

I'll add these between existing sections, in this order:
- **"How HyzenPro reviews tools"** — 3-step process strip (Test → Score → Publish) right after the hero, builds trust early.
- **"Latest guides"** — 3 featured guide cards (magazine-style with serif headlines), seeded from a small `guides` table.
- **"What creators say"** — testimonial carousel (3 quotes) before the quiz CTA.
- **Newsletter capture** — single email field, stores in `subscribers` table, in the footer area.

## Technical notes
- Stack: TanStack Start + TanStack Query loaders (`ensureQueryData` + `useSuspenseQuery`), server fns under `src/lib/tools.functions.ts`.
- DB access: anon SELECT for `tools` and `guides` (public reads); `subscribers` and `analytics_events` writeable via public server fn that uses `supabaseAdmin` with strict input validation (no auth required, public site).
- All queries go through `createServerFn` — no admin client in loaders.
- Search uses `ilike` with `%query%` on name/category/tagline.

## Out of scope (flag if you want it)
- Admin dashboard for managing tools (seed via migration for now).
- Real auth / user accounts.
- A separate detail page per tool (links will go to `#` for now; easy to add later).

Approve and I'll start with enabling Cloud + the migration, then build top-down.